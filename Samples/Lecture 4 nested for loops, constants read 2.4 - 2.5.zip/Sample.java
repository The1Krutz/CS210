public class Sample {
    public static void main(String[] args) {
        int first;
        int second;
        first = 13;
        second = first + 2;
        first = 50;
        System.out.println(first);
        System.out.println(second);
    }
}
