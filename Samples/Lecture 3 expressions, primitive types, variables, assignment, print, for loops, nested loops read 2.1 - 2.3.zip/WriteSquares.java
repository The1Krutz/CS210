public class WriteSquares {
    public static void main(String[] args) {
        System.out.println(1 + " squared = " + (1 * 1));
        System.out.println(2 + " squared = " + (2 * 2));
        System.out.println(3 + " squared = " + (3 * 3));
        System.out.println(4 + " squared = " + (4 * 4));
        System.out.println(5 + " squared = " + (5 * 5));
    }
}
