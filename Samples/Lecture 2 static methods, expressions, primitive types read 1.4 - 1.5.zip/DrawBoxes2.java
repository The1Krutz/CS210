public class DrawBoxes2 {
    public static void main(String[] args) {
        drawBox();
        System.out.println();
        drawBox();
    }

    public static void drawBox() {
        System.out.println("+------+");
        System.out.println("|      |");
        System.out.println("|      |");
        System.out.println("+------+");
    }
}
